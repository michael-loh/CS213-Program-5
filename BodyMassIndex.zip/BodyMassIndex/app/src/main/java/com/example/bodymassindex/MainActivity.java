package com.example.bodymassindex;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.view.View;
import android.widget.Toast;
import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {

    Button calculateBMI;
    Button getAdvice;
    TextView showBMI;
    EditText weight;
    EditText height;
    RadioButton metric;
    RadioButton imperial;

    protected static float bmi;

    private static DecimalFormat df2 = new DecimalFormat("#.##");

    /**
     * This is the on Create method that loads the app and assigns the fields in this class to their corressponding objects.
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        calculateBMI = findViewById(R.id.calculateBMI);
        getAdvice = findViewById(R.id.getAdvice);
        showBMI = findViewById(R.id.showBMI);
        weight = findViewById(R.id.weight);
        height = findViewById(R.id.height);
        metric = findViewById(R.id.metric);
        imperial = findViewById(R.id.imperial);

        imperial.setChecked(true);
    }


    public void calculateBMI( View view ){

        if(fieldsEmpty()){
            emptyFieldsError();
            return;
        }

        double w = Double.parseDouble( weight.getText().toString() );
        double h = Double.parseDouble( height.getText().toString() );

        if(w == 0 || h == 0){
            zeroFieldError();
            return;
        }

        boolean m = metric.isChecked();

        bmi = BodyMassIndex.calculateBMI(w, h, m );
        showBMI.setText(  df2.format(bmi) );
    }

    public void showAdvice( View view ){
        if(showBMI.getText().length() == 0){
            Toast.makeText(MainActivity.this, "Error: Must calculate BMI before you can get advice", Toast.LENGTH_SHORT).show();
            return;
        }
        Intent intent = new Intent( this, ShowAdvice.class);
        startActivity(intent);
    }

    public void changeHintImperial(View view){
        weight.setHint("Enter weight in lb");
        height.setHint("Enter height in inches");
    }

    public void changeHintMetric(View view){
        weight.setHint("Enter weight in kg");
        height.setHint("Enter height in meters");
    }

    private void emptyFieldsError(){
        Toast.makeText(MainActivity.this, "Error: Fill in all fields", Toast.LENGTH_SHORT).show();
    }

    private void zeroFieldError(){
        Toast.makeText(MainActivity.this, "Error, Weight and height must be non 0 values.", Toast.LENGTH_SHORT).show();
    }

    private boolean fieldsEmpty(){
        if(weight.getText().length() == 0 || height.getText().length() == 0){
            return true;
        }
        return false;
    }


}
