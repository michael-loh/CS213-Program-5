package com.example.bodymassindex;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.File;

public class ShowAdvice extends AppCompatActivity {

    TextView bmiTextView;
    TextView advice;
    ImageView imageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_advice);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        bmiTextView = findViewById(R.id.bmiTextView);
        advice = findViewById(R.id.advice);
        imageView = findViewById(R.id.imageView);

        displayAdvice(MainActivity.bmi);
    }

    private void displayAdvice(float bmi){
        File img;
        if(bmi < 18.5){
            imageView.setImageResource(R.drawable.underweight);
            bmiTextView.setBackgroundColor(Color.parseColor("#1DEEE6"));
            bmiTextView.setText("Underweight");
            advice.setText("Being underweight is a fixable problem. Focus on setting a healthy eating routine and stick to it.");
        }
        else if(bmi <= 24.9){
            imageView.setImageResource(R.drawable.normal);
            bmiTextView.setBackgroundColor(Color.parseColor("#66DB73"));
            bmiTextView.setText("Normal");
            advice.setText("Your current BMI is ideally where you want to be at. Continue to maintain healthy eating habits and exercise.");
        }
        else if(bmi <= 29.9){
            imageView.setImageResource(R.drawable.overweight);
            bmiTextView.setBackgroundColor(Color.parseColor("#FF9800"));
            bmiTextView.setText("Overweight");
            advice.setText("The answer to losing weight and getting to a normal BMI is exercise. Cardio is a big plus, as it may help to burn unwanted fat.");
        }
        else{
            imageView.setImageResource(R.drawable.obese);
            bmiTextView.setBackgroundColor(Color.parseColor("#F44336"));
            bmiTextView.setText("Obese");
            advice.setText("Obesity is an issue that should concern you, but it is definitely a solvable problem. The best way to tackle this problem is through a balanced diet and exercise.");
        }
    }
}
